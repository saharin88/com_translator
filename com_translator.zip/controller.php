<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class TranslatorController extends BaseController
{

	protected $default_view = 'files';


}